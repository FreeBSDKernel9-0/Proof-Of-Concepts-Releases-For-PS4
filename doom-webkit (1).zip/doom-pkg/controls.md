# Controls & Features

Three editable layers (`default.cfg`, `REMAP_*`, `PAD_MAP`) + music, saves, and
the melt-overlay. Scroll down for per-feature notes.

## Layer 1 — `default.cfg` (the DOOM engine itself)

Values are DOS scan codes. Chocolate Doom's `scantokey[]` table translates them
to internal DOOM keys at load time.

| Action        | scan code | Key     |
|---------------|-----------|---------|
| forward       | 17        | W       |
| back          | 31        | S       |
| turn left     | 24        | O       |
| turn right    | 25        | P       |
| strafe left   | 30        | A       |
| strafe right  | 32        | D       |
| fire          | 57        | SPACE   |
| use           | 18        | E       |
| strafe hold   | 46        | C       |
| run hold      | 42        | LSHIFT  |

Arrow keys are hardcoded aliases for turn/forward/back and always work.

**Heads-up on `fire`**: in this Cloudflare WASM build, `key_fire 57` is
effectively dead — pressing Space at a fresh E1M1 with AMMO=50 leaves AMMO=50.
The engine's SDL2→DOM scancode path for space isn't wiring through. That's why
Layer 2 routes fire via a synthesized **mouse click** instead of a keypress.
Mouse button 1 is hard-wired to fire in chocolate-doom (`mousebfire=0`) and
reaches the engine directly, so it always works.

## Layer 2 — `index.html` REMAP block (recommended)

Pure JS pre-filter intercepting `keydown`/`keyup` at the window (capture phase)
and synthesizing a new event on the canvas. Two kinds of remap:

```js
// Synthesize a LEFT MOUSE CLICK on the canvas.
var REMAP_CLICK = {
    'Backspace': true,      // Shoot
};

// Synthesize a KEYBOARD event with the given identity.
var REMAP_KEY = {
    'KeyF': { code: 'KeyE', key: 'e', keyCode: 69 },   // Pick up
};

// Numeric keyCode override for old WebKit — rewrites ev.keyCode before dispatch
// so ancient Safari/PS4 routes the synth event with the right numeric code.
var REMAP_KEYCODE = {
    70: 69,  // F(70) -> E(69)
};
```

Hold-to-fire works: Backspace keydown → mousedown, keyup → mouseup. Auto-repeat
is filtered so a held key doesn't fire a new shot every frame — you get one
shot per press, same as a real Doom mouse.

Player-facing keyboard bindings after REMAP:

| Action     | Key                                                                    |
|------------|------------------------------------------------------------------------|
| Move       | W A S D / arrows                                                       |
| Turn       | O P / ← →                                                              |
| Shoot      | Backspace                                                              |
| Pick up    | F                                                                      |
| Jump       | (unsupported — engine limitation)                                      |
| Run        | Left Shift                                                             |
| Strafe     | C (hold)                                                               |
| Weapons    | 1..7                                                                   |
| Menu       | Esc                                                                    |
| Music prev | B                                                                      |
| Music next | N                                                                      |
| Music mute | M                                                                      |
| Game Over  | G (trigger melt overlay manually; R dismisses it)                       |

### Adding more rebinds

- Make another key fire: `REMAP_CLICK['ControlLeft'] = true;`
- Map one key to another: `REMAP_KEY['KeyG'] = { code:'KeyE', key:'e', keyCode:69 };`

## Layer 3 — `PAD_MAP` (DualShock 4 / standard gamepad)

Wired through `navigator.getGamepads()` (with `webkitGetGamepads()` fallback
for older PS4 firmware). Polled every `requestAnimationFrame`, edge-detected,
and routed through the same synth primitives as Layer 2 — so any rebind you
can express in the keyboard path also works for the pad.

```js
// Each entry is { fire:true } for a synthesized mouse click, OR
//                { key: {code, key, keyCode} } for a synthesized keypress.
var PAD_MAP = {
    buttons: {
        7:  { fire: true },                                       // R2 -> shoot
        0:  { key: { code:'KeyE', key:'e', keyCode:69 } },        // Cross -> pick up
        2:  { key: { code:'KeyE', key:'e', keyCode:69 } },        // Square -> pick up (alt)
        5:  { fire: true },                                       // R1 -> shoot (alt)
        6:  { key: { code:'ShiftLeft', key:'Shift', keyCode:16 } },// L2 -> run
        4:  { key: { code:'ShiftLeft', key:'Shift', keyCode:16 } },// L1 -> run (alt)
        12: { key: { code:'KeyW', key:'w', keyCode:87 } },        // D-up -> forward
        13: { key: { code:'KeyS', key:'s', keyCode:83 } },        // D-dn -> back
        14: { key: { code:'KeyO', key:'o', keyCode:79 } },        // D-lf -> turn left
        15: { key: { code:'KeyP', key:'p', keyCode:80 } },        // D-rt -> turn right
        9:  { key: { code:'Escape', key:'Escape', keyCode:27 } }, // Options -> menu
        1:  { key: { code:'Escape', key:'Escape', keyCode:27 } }, // Circle -> back
    },
    axes: {
        0: { pos: 'KeyD', neg: 'KeyA', deadzone: 0.30 }, // LX -> strafe
        1: { pos: 'KeyS', neg: 'KeyW', deadzone: 0.30 }, // LY -> move
        2: { pos: 'KeyP', neg: 'KeyO', deadzone: 0.45 }, // RX -> turn
    },
};
```

DS4 button numbers in "standard" mapping:

```
0=Cross   1=Circle  2=Square   3=Triangle
4=L1      5=R1      6=L2       7=R2
8=Share   9=Options 10=L3      11=R3
12=Up    13=Down   14=Left    15=Right
16=PS    17=Touchpad
```

Some old PS4 firmwares mis-report buttons as booleans or raw ints instead of
`GamepadButton` objects — the poll loop handles both forms.

## Music

No SDL_mixer in this WASM build, so music is played *out-of-band* via HTML5
`<audio>`. Twelve OGG Vorbis tracks live in `music/` — rendered from the MUS
lumps in `doom1.wad` via `mus2mid` + `fluidsynth` (FluidR3_GM soundfont). OGG
was picked because it's supported on Safari 11+ and PS4 FW 5.0+.

| Key | Effect             |
|-----|--------------------|
| N   | next track         |
| B   | previous track     |
| M   | mute / unmute      |

Level detection: the page hooks `Module.print` and watches for `E[1-4]M[1-9]`
in the engine's stdout. When a match fires, the player is dropped onto that
level's track. If detection misses (older engine builds don't always print the
map name), a 12-second fallback timer switches from the intro jingle to the
E1M1 loop so music keeps playing once you're in-game.

All music paths are editable at the top of `index.html` under `var MUSIC = {
... }`. Point it at your own OGGs/MP3s if you want different tracks.

## Save games

Chocolate Doom is pointed at `/save` via `-savedir /save` and writes
`doomsav0.dsg`..`doomsav7.dsg` there as you use the Save Game menu. Because
this Cloudflare WASM build was **not** linked with `-lidbfs.js`,
`Module.FS.filesystems.IDBFS` is `undefined` and `FS.syncfs` is a no-op — so
the page ships its own small shim (`saveStore` in `index.html`) using the
plain IndexedDB API:

- **Backing store**: database `doom-save`, object store `files`, keyed by
  filename. Each record is `{ name, bytes (Uint8Array), size, mtime }`.
- **Restore**: `saveStore.restore()` runs in `preRun` and is gated by
  `Module.addRunDependency('save-restore')`, so the engine blocks until every
  record has been copied from IndexedDB into `/save`. Without this gate the
  Load Game menu reads slot labels from an empty directory and shows
  "EMPTY SLOT" forever.
- **Flush**: `saveStore.flushIfDirty()` runs on a 2-second interval plus
  once on `beforeunload`. It snapshots `/save` (name + size + mtime) and
  only writes when the snapshot has changed, so idle gameplay is free.

Saves persist across tab refresh, across browser restart, and across the
PS4's sleep/resume. To wipe saves: DevTools → Application → IndexedDB →
delete the `doom-save` database.

In-game controls for saving/loading (standard Doom):
- `F6` → Save Game menu (first time: pick a slot, type a name, Enter)
- `F9` → Load Game (pick slot, Enter)
- `F2` / `F3` open the same menus through the main Menu path

## Game Over melt overlay

This is the real DOOM wipe — `f_wipe.c` transliterated to JS. On trigger:

1. The live game canvas is drawn onto an offscreen 2D canvas.
2. That snapshot is sliced into **160 vertical strips**, each with its own
   Y offset. `y[0] = -(rand() % 16)`, `y[i] = clamp(y[i-1] ± 1, -15, 0)` — so
   neighbouring strips drift by at most 1 unit, same as the original.
3. On every 35-Hz tick, each strip's `y` gains `1` while under 16, then `8`
   thereafter until it passes the bottom (DOOM's 200-unit tall screen).
4. Strips are re-drawn each rAF, revealing black beneath.
5. The "GAME OVER" banner fades in ~1.6 s after the strips are on their way.

The "real-pixels" snapshot only works because `index.html` patches
`HTMLCanvasElement.prototype.getContext` BEFORE the engine loads, forcing
`preserveDrawingBuffer: true` on the WebGL context. Without that patch the
browser clears the drawing buffer after every compositor present and
`drawImage(canvas)` returns blank.

| Key | Effect                                         |
|-----|------------------------------------------------|
| G   | manually trigger the overlay (demo / testing)  |
| R   | dismiss the overlay (engine respawn is Use)    |

Auto-trigger on real player death is best-effort: chocolate-doom doesn't print
a "you died" line that we can hook. If you want it to fire automatically,
rebuild the WASM with a stdout printf when `plr->playerstate == PST_DEAD` is
set, then the page's `levelDetect.onText` regex will pick it up and call
`melt.trigger()`.

## DOS scan code cheat sheet (if you prefer Layer 1)

```
ESC=1  1..9=2..10  0=11  -=12  ==13  BS=14  TAB=15
Q=16 W=17 E=18 R=19 T=20 Y=21 U=22 I=23 O=24 P=25
[=26 ]=27 ENTER=28  CTRL=29
A=30 S=31 D=32 F=33 G=34 H=35 J=36 K=37 L=38 ;=39
'=40 `=41 LSHIFT=42 \=43
Z=44 X=45 C=46 V=47 B=48 N=49 M=50 ,=51 .=52 /=53
RSHIFT=54  ALT=56  SPACE=57  CAPS=58
F1..F10=59..68
UP=200  LEFT=203  RIGHT=205  DOWN=208
```

## A note on "jump"

There is no `key_jump` — Chocolate Doom is a vanilla port and the original
1993 engine didn't have jumping. If you need jump, you'd have to port a
different engine (GZDoom / PrBoom+ / Eternity) to WebAssembly, which is a
separate project.
